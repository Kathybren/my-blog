import * as actionTypes from './actionTypes'
const defaultStatue = {}

export default (state = defaultStatue, action) => {
    return state
}