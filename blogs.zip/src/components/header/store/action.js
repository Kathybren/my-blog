import * as actionTypes from './actionTypes'
export const aaa = ( ) => {
    type: actionTypes.GET_LIST
}