import React, { Component } from 'react'
import Card from '../../container/card/card'
import './index.scss'

class Study extends Component {
  render() {
    return (
      <div className="stydy">
        <div className="stydyContent">
          <Card />
        </div>
      </div>
    )
  }
}
export default Study