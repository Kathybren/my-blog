import React, { Component } from 'react'
import './index.scss'

class Detail extends Component {
  render() {
    return (
      <div className="detail">
        <div className="detailContent">
        
        </div>
      </div>
    )
  }
}
export default Detail