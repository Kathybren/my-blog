
import React, { Component } from 'react'
import Card from '../../container/card/card'
import './index.scss'

class Think extends Component {
  render() {
    return (
      <div className="think">
        <div className="thinkContent">
          <Card />
        </div>
      </div>
    )
  }
}
export default Think